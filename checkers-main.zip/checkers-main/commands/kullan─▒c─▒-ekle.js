const { Client, EmbedBuilder } = require("discord.js");
const db = require("croxydb")
module.exports = {
  name: "kullanıcı-ekle",
  description: "Özel odana kullanıcı eklersin!",
  type: 1,
  options: [],

  run: async(client, interaction) => {

  

  }

};
