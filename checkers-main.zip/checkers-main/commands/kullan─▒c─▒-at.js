const { Client, EmbedBuilder } = require("discord.js");
const db = require("croxydb")
module.exports = {
  name: "kullanıcı-at",
  description: "Özel odandan kullanıcı atarsın!",
  type: 1,
  options: [],

  run: async(client, interaction) => {

  

  }

};
