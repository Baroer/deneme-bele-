const { Client, EmbedBuilder } = require("discord.js");

module.exports = {
  name: "kart-oluştur",
  description: "Kredi kartı oluşturursun!",
  type: 1,
  options: [],

  run: async(client, interaction) => {

  }

};
